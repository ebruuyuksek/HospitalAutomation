﻿using Ödev;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HastOtomasyon
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        
        private void Form1_Load(object sender, EventArgs e)
        {
           
        }


        private void btnKaydet_Click(object sender, EventArgs e)
        {
            Hasta hasta = new Hasta(); //Hasta class'ından bir nesne türettik
            hasta.Ad = tbAd.Text;  //hastanın özelliklerine giriş verilerimizi atıyoruz
            hasta.Soyad = tbSoyad.Text;
            hasta.Bolum = tbBolum.Text;
            hasta.DoktorAd = tbDoktorAdi.Text;
            hasta.Tc = tbTC.Text;       
            hasta.odaNo = tbOda.Text;
            hasta.Tarih = dateTimePicker1.Text;
            hasta.ucret = Convert.ToInt32(tbUcret.Text); //int değer olduğu için Int'e dönüştürdük  
            hasta.sifre = tbSifre.Text; 
            //manuel olarak eklediğimiz DataGridView'a sırasıyla verilerimizi ekliyoruz
            dataGridView1.Rows.Add(hasta.Tc, hasta.Ad, hasta.Soyad,hasta.Bolum,hasta.DoktorAd,hasta.Tarih, hasta.odaNo,hasta.ucret);          
          
        }

        private void tbAd_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnTemizle_Click(object sender, EventArgs e)
        {
            //textbox'ları temizliyoruz
            tbAd.Clear();
            tbSoyad.Clear();
            tbBolum.Clear();
            tbDoktorAdi.Clear();
            tbTC.Clear();
            tbOda.Clear();
            tbUcret.Clear();
            tbSifre.Clear(); 
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //aranan herhangi bir veriyi buluyoruz
            //büyük küçük harfe takılmaması için ToUpper fonksiynu kullandık 
            //for döngüsünü datagrid'deki bütün hücreleri taraması için oluşturduk.
            
            string aranan = textBox8.Text.Trim().ToUpper();
            for (int i = 0; i <= dataGridView1.Rows.Count - 1; i++)
            {
                foreach (DataGridViewRow row in dataGridView1.Rows)
                {
                    foreach (DataGridViewCell cell in dataGridView1.Rows[i].Cells)
                    {//foreach döngüsünde her bir hücrede arammaya başlıyoruz 
                        if (cell.Value != null) //burada hücrenin boş olmaması şartını sağlıyoruz
                        {
                            if (cell.Value.ToString().ToUpper() == aranan) 
                            { //hücre değeri aranan'a eşitse o hücreyi koyu turkuaza boyuyoruz
                                cell.Style.BackColor = Color.DarkTurquoise; 
                                break;
                            }
                        }
                    }
                }
            }
        }
    }
}
