﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ödev
{ 
    class Hasta
    {
        //Hasta classının özellikleri
        public string Tc;
        public string Ad;
        public string Soyad;
        public string Bolum;
        public string DoktorAd;
        public string Tarih;
        public string odaNo;
        public int ucret;
        public string sifre;
    


        public void Kayıt_Ol()
        {
           
            
            //Burada T.C kimlik numarası ile bir üyelik oluşturabilir.
        }

        public void Randevu_Al()
        {
            /*öncelikle poliklinik seçilecek, sonra o poliklinikteki doktorlar listelenecektir.
            Doktor seçimi yapıldıktan sonra bir saat seçim ekranı oluşacaktır.Hastalar uygun saati seçerek randevu alabileceklerdir. */
        }



  
    }
 
}
