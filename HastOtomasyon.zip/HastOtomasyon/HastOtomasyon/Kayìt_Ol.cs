﻿namespace HastOtomasyon
{
    internal class Kayıt_Ol
    {
    }
}