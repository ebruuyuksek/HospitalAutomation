﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ödev
{
    class Doktor
    {

        private void Hasta_Listesi()
        {
            //Randevu tarihine göre hasta listesini görebilir.
        }

        private void Siradaki_Hastayi_Cagir()
        {
            //Sıradaki hastayi bir butona basarak çağırabilir.
        }


    }
    }
