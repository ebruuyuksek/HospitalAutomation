﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ödev
{
    class BasHekim
    {
        private void doktor_ekle()
        {
            //yeni doktor kaydı ekleme
        }
        private void doktor_Sil()
        {
            //doktor kaydı silme
        }
        private void hemşire_ekle()
        {
            //yeni hemşire kaydı ekleme
        }
        private void hemşire_Sil()
        {
            //hemşire kaydı silme
        }
        private void personel_ekle()
        {
            //yeni personel kaydı  ekleme
        }
        private void personel_Sil()
        {
            //personel kaydı silme
        }

        private void Calişanlari_Listele()
        {
            // tüm hastane çalışanlarının bilgilerini görmeyi saglar
        }




    }
}
